//
//  SecondViewController.swift
//  Tab Example
//
//  Created by Henry Westerman on 5/27/16.
//  Copyright © 2016 Henry Westerman. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    

    @IBOutlet weak var numLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       numLabel.adjustsFontSizeToFitWidth = true
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        numLabel.text = String(DataInstance.sharedInstance.addnumber * DataInstance.sharedInstance.multnumber)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}

