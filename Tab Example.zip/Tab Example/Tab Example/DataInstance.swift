//
//  DataInstance.swift
//  Tab Example
//
//  Created by Henry Westerman on 6/1/16.
//  Copyright © 2016 Henry Westerman. All rights reserved.
//

import Foundation

class DataInstance {
    var addnumber: Int = 0
    var name: String = "Luke"
    var multnumber: Int = 0
    static let sharedInstance = DataInstance()
    
    
    
    init(){
        
    }
}