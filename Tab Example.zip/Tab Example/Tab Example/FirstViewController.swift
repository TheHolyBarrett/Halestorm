//
//  FirstViewController.swift
//  Tab Example
//
//  Created by Henry Westerman on 5/27/16.
//  Copyright © 2016 Henry Westerman. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        mLabel.adjustsFontSizeToFitWidth = true
        nLabel.adjustsFontSizeToFitWidth = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBOutlet weak var mLabel: UILabel!

    @IBOutlet weak var nLabel: UILabel!
    
    @IBOutlet weak var numStepper: UIStepper!
    
    @IBOutlet weak var multStepper: UIStepper!
   
    
  
    @IBAction func numstepperTouched(sender: UIStepper) {
        
        numStepper.wraps = true
        numStepper.autorepeat = true
        numStepper.maximumValue = 100
        DataInstance.sharedInstance.addnumber = Int(numStepper.value)
        nLabel.text=Int(numStepper.value).description
    }
    @IBAction func multstepperTouched(sender: UIStepper) {
        multStepper.wraps = true
        multStepper.autorepeat = true
        multStepper.maximumValue = 100
        DataInstance.sharedInstance.multnumber = Int(multStepper.value)
        mLabel.text=Int(multStepper.value).description
    }

}

