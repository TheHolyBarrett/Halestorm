//
//  CreditsViewController.swift
//  Tab Example
//
//  Created by Henry Westerman on 6/1/16.
//  Copyright © 2016 Henry Westerman. All rights reserved.
//

import UIKit

class CreditsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        henryLabel.hidden=true
        henryLabel.adjustsFontSizeToFitWidth = true
        creditsLabel.adjustsFontSizeToFitWidth = true

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var creditsLabel: UILabel!

    @IBOutlet weak var henryLabel: UILabel!
    @IBOutlet weak var hiddenButton: UIButton!
    @IBAction func hiddenButtonPressed(sender: UIButton) {
        henryLabel.hidden=false
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
