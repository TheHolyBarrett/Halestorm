//
//  SecondViewController.swift
//  Halestorm2
//
//  Created by Henry Westerman on 6/22/16.
//  Copyright © 2016 Henry Westerman. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        thanksLabel.hidden=true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBOutlet weak var thanksLabel: UILabel!
  
    @IBAction func checkInPressed(sender: AnyObject) {
        DataInstance.sharedInstance.absent=false
        thanksLabel.hidden=DataInstance.sharedInstance.absent
        
    }

}

