//
//  FirstViewController.swift
//  Halestorm2
//
//  Created by Henry Westerman on 6/22/16.
//  Copyright © 2016 Henry Westerman. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
  
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBOutlet weak var responseLabel: UILabel!
    var responseInt: Int = 0
    
    @IBAction func okButtonPressed(sender: UIButton) {
        responseInt = 1
        DataInstance.sharedInstance.lockdownButtonChoice=responseInt
        responseLabel.text=DataInstance.sharedInstance.lockdownButtonChoice.description
       // send()
        
        
    }
    
    @IBAction func notOkButtonPressed(sender: UIButton) {
        responseInt = 2
        DataInstance.sharedInstance.lockdownButtonChoice=responseInt
        responseLabel.text=DataInstance.sharedInstance.lockdownButtonChoice.description
   //   send()
    }
    
    
    
    func send(){
        
    /*    let request = NSMutableURLRequest(URL: NSURL(string: "http://flik.ma1geek.org/getMeals.php?date=2016-03-08")!)
        request.HTTPMethod = "POST"
        let postString = responseInt.description
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            
            print("response = \(response)")
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString)")
        }
        task.resume()*/
        
        
    }
    

}

