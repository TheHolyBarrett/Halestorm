//
//  FirstViewController.swift
//  Halestorm2
//
//  Created by Henry Westerman on 6/22/16.
//  Copyright © 2016 Henry Westerman. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBOutlet weak var responseLabel: UILabel!
    var responseInt: Int = 0
    
    @IBAction func okButtonPressed(sender: UIButton) {
        responseInt = 1
        DataInstance.sharedInstance.lockdownButtonChoice=responseInt
        responseLabel.text=DataInstance.sharedInstance.lockdownButtonChoice.description
        
    }
    
    @IBAction func notOkButtonPressed(sender: UIButton) {
        responseInt = 2
        DataInstance.sharedInstance.lockdownButtonChoice=responseInt
        responseLabel.text=DataInstance.sharedInstance.lockdownButtonChoice.description
    }
    

}

