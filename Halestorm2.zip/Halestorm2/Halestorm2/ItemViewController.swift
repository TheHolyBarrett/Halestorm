//
//  ItemViewController.swift
//  Halestorm2
//
//  Created by Henry Westerman on 6/22/16.
//  Copyright © 2016 Henry Westerman. All rights reserved.
//

import UIKit

    
    class ItemViewController: UIViewController, UITableViewDataSource {
        
        let locations = [
            ("ACC"),
            ("Wigg Hall"),
            ("Student Center"),
            ("King Theater"),
            ("Straus Hall")
            
        ]

        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view, typically from a nib.
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
        func numberOfSectionsInTableView(tableView: UITableView) -> Int {
            return 1
            
        }
        
        func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return locations.count
        }
        
        
        
        func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
            
            let cell=UITableViewCell()
            let location = locations[indexPath.row]
            cell.textLabel?.text = location
            return cell
        }
        
        
        func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
            return "Assembly Locations"
        }
    }
    
    

    

