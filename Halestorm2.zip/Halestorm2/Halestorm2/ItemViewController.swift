//
//  ItemViewController.swift
//  Halestorm2
//
//  Created by Henry Westerman on 6/22/16.
//  Copyright © 2016 Henry Westerman. All rights reserved.
//

import UIKit

    
    class ItemViewController: UIViewController, UITableViewDataSource {
        
        var responses:NSArray = []
        @IBOutlet weak var tableView: UITableView!
        

        override func viewDidLoad() {
            super.viewDidLoad()
            get();
            // Do any additional setup after loading the view, typically from a nib.
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
        
        
        func get(){
            print("Getting")
            let url = NSURL(string: "http://flik.ma1geek.org/getMeals.php?date=2016-03-08")
            print(NSData(contentsOfURL: url!))
            let data = NSData(contentsOfURL: url!)
            print(data)
           responses = try! NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers) as! NSArray
            tableView.reloadData()
            
        }
        
        
        func numberOfSectionsInTableView(tableView: UITableView) -> Int {
            return 1
            
        }
        
        func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return responses.count
        }
        
        
        
        func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
            
            let cell=UITableViewCell()
            let number = responses[indexPath.row]
            cell.textLabel?.text = number as! String
            return cell;
            
            
        }
        
        
        func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
            return "Responses"
        }
        
        
       
        
        
    }
    
    

    

