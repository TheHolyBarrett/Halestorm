//
//  DataInstance.swift
//  HalestormSwift1
//
//  Created by Henry Westerman on 6/22/16.
//  Copyright © 2016 Henry Westerman. All rights reserved.
//

import Foundation

class DataInstance {
    var lockdownButtonChoice: Int = 0
    //1 = OK 2 = not OK
    var absent: Bool = true
    //make it false every morning
    
    
    
    static let sharedInstance = DataInstance()
    
    init(){
        
    }
}
