//  HTMLTestUtilities.h
//
//  Public domain. https://github.com/nolanw/HTMLReader

#import <XCTest/XCTest.h>

extern NSString * html5libTestPath(void);

extern BOOL ShouldRunTestsForParameterizedTestClass(Class class);
