//
//  GroupViewController.swift
//  MiltonMobileIOS
//
//  Created by Henry Westerman on 6/28/16.
//  Copyright © 2016 Milton Academy. All rights reserved.
//



//CURRENT BUGS:


import UIKit
import Alamofire



class GroupViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    override func viewDidLoad() {
      
        super.viewDidLoad()
        loadNames()
       // getNames()
        //REPLACE 5 WITH THE LENGTH OF THE STUDENT ARRAY OF THE CLASS
        
        
    
    }
    
    
    //refresh method
    func refresh(){
       // print("Refreshing")
        cellCounter=0
        
        tableView.reloadData()
      //  print("did I get here?")

        refreshedTimes=refreshedTimes+1
        print("Refresh number " + refreshedTimes.description + " Completed")
        print("AbsentArray:")
        print(absentArray)
        
        createMaps()
       //THEN I NEED TO RESET

    }
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    //variables
    var strURL: String = ""
    var numStudents: Int = 0
    var refreshedTimes:Int=0
    var absentMode:Bool=false
    var absentArray: [Bool] = []
    var trueTableMap: [Int] = []
    var falseTableMap: [Int] = []
    var TableData: JSON = []
   // var tableArray = []
    var nameArray: [String] = []
    var studentArray: [Student] = []
    
    
    //buttons
    @IBOutlet weak var modeButton: UIButton!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var submitButton: UIButton!
    
    //buttons clicked
    
    @IBAction func updateButtonClicked(sender: UIButton) {
        
        refresh()
        
    }
    @IBAction func submitButtonClicked(sender: UIButton) {
        var presentStudents: [Student] = []
        
        for i in 0...(falseTableMap.count-1){
            presentStudents.append(studentArray[falseTableMap[i]])
            print("Adding student to upload: " + presentStudents[i].FullName)
        
        }
        AttendanceLocalSave.sharedInstance.checkedStudents=presentStudents
        presentStudents=[]
        
        for i in 0...AttendanceLocalSave.sharedInstance.checkedStudents.count-1{
        print(AttendanceLocalSave.sharedInstance.checkedStudents[i].FullName)
        }
        //upload dat good good
        
        
        
    }
    
    @IBAction func modebuttonClicked(sender: UIButton) {

        if(absentMode==true){
            absentMode=false
            print(absentMode.description)
           // print("Absent mode is currently " + absentMode.description)
           
                refresh()
    
        }
       else{
            absentMode=true
            print(absentMode.description)

            refresh()
        }
        
    }
    
    //Table View stuff
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var navBar: UINavigationBar!
    @IBOutlet weak var navTitle: UINavigationItem!
    
    

    //"on click"
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let row = indexPath.row
        
        print("Row: \(row) clicked on Group")
        
        //y REPRESENTS THE NUMBER IN THE MAP, which also goes directly to the rows
        
        if(absentMode==true){
            absentArray[falseTableMap[row]]=true //could I just use row?
            
            if let cell = tableView.cellForRowAtIndexPath(indexPath){
                if(cell.accessoryType == .Checkmark){
                    cell.accessoryType = .None
                }
                else{
                    cell.accessoryType = .Checkmark
                }
            }
            
            
                  }
        else{
            absentArray[trueTableMap[row]]=false
            if let cell = tableView.cellForRowAtIndexPath(indexPath){
                if(cell.accessoryType == .Checkmark){
                    cell.accessoryType = .None
                }
                else{
            cell.accessoryType = .Checkmark
                }
            }

        }
        
        
       // print(absentArray)
        
        
        
        
            
        }
        
        
        
        
        
    
    
    
     func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        //NUMBER OF SECTIONS
        return 1
        
    }
    
     func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //  return data.count                 NUMBER OF ROWS
        
        if(absentMode==true){
            return falseTableMap.count
        }
        else{
            return trueTableMap.count
        }
        
        
         }
    
    
    
    
    var cellCounter: Int=0
     func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell { //POPULATING CELLS
    
        let cell=UITableViewCell()
        
        if(absentMode==true){
            if(indexPath.row<falseTableMap.count){
                cell.textLabel?.text=(studentArray[falseTableMap[indexPath.row]].FullName)
               // print("what's")
                cell.accessoryType = .Checkmark
                //print("good")
               // print(cell.accessoryType.rawValue.description)
                

                //print("Added cell " + cellCounter.description)
                return cell;
          }
            
        }
        else{
            if(indexPath.row<trueTableMap.count){
                cell.textLabel?.text=(studentArray[trueTableMap[indexPath.row]].FullName)
               // print("what's")
                cell.accessoryType = .None
                //print("good")
                //print(cell.accessoryType.rawValue.description)
                return cell;
            }
        }
        
     cell.textLabel?.text=("")
        return cell;
        

        
    }
    
    func createMaps() {
        falseTableMap=[]
        trueTableMap=[]
        for i in 0...(absentArray.count-1){
            if(absentArray[i]==true){
                trueTableMap.append(i)
            }
            else{
                falseTableMap.append(i)
            }
            
        }
        print("TrueTableMap:")
        print(trueTableMap)
        print("FalseTableMap:")
        print(falseTableMap)
        
        
    }
    
     func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        //HEADER
        if(absentMode==true){
            return "Students Already Checked In"
        }
        else{
            return "Students Not Yet Checked In"
        }
    }
    
    
    
    
    func loadNames() {
        //I removed parameters from the request (see original "loadActivities" in activities file
        SwiftSpinner.show("Loading Names");
        let strURL: String = "http://signin.ma1geek.org/getStudents.php?year=2017"

        
        
        Alamofire.request(.GET,strURL).responseJSON{response in
            print(response.2.error);
            //print(response.2.description);
            SwiftSpinner.hide();
            if let data = response.2.value {
                let json = JSON(data)
                self.TableData = json
                dispatch_async(dispatch_get_main_queue(), {
                    self.tableView.reloadData()
                    print("Loaded names")
                    self.getNames()
                    return
                })
                // see https://github.com/SwiftyJSON/SwiftyJSON
            }
            else {
                let alert = UIAlertView();
                alert.title = "Try again"
                alert.message = "Please check your network connection to load your groups."
                alert.addButtonWithTitle("OK")
                alert.show()
            }
            
        }
        
    }//load
    
    
   func getNames(){
   // print(TableData)
    
    var tableAsDictionary = TableData.dictionaryValue
    let key : String = Array(tableAsDictionary.keys)[0]
    let testc = tableAsDictionary[key]!.count
    
    print("table array count(2)= " + (testc.description))
    
    var stillCounting: Bool = true
    var x: Int = 0
    
   while(stillCounting==true) {
        //how to make it stop when it has counted them all?
    if(x>testc){
        stillCounting=false
    }
    else{
            let roleJO = TableData["Students"][x]
            let roleFirstName:String = roleJO["Firstname"].stringValue
            let roleLastName:String = roleJO["Lastname"].stringValue
            let roleID:String = roleJO["StudentID"].stringValue
            numStudents=numStudents+1
            print("Added student number " + numStudents.description + " With name " + roleFirstName + " " + roleLastName)
            let stu = Student(FirstName:roleFirstName, LastName:roleLastName, StudentID:roleID,test:x)
            studentArray.append(stu)
            numStudents=numStudents+1
    
    
    x=x+1
    }
    
    }
    
    
    
    
    for i in 1...studentArray.count {
        absentArray.append(true)
    }
    
    
    
    createMaps()
    tableView.reloadData()
    
    
    


    
    }
    
    
    
    
    
    
    
    
    

    
    
    
}
