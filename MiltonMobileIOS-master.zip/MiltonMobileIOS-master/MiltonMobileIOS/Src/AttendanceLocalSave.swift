//
//  AttendanceLocalSave.swift
//  MiltonMobileIOS
//
//  Created by Henry Westerman on 7/1/16.
//  Copyright © 2016 Milton Academy. All rights reserved.
//

import Foundation


class AttendanceLocalSave {
    
   var checkedStudents: [Student] = []
    static let sharedInstance = AttendanceLocalSave()
    var url: String = ""
    
    
    
    init(){
        
    }
    
    func changeCheckInArray( checked: [Student]){
        checkedStudents = checked
    }
    
    
}