//
//  RoleTableViewController.swift
//  MiltonMobileIOS
//
//  Created by Henry Westerman on 6/28/16.
//  Copyright © 2016 Milton Academy. All rights reserved.
//


import UIKit
import Alamofire


class RoleTableViewController: UIViewController, UITableViewDataSource{


    
    @IBOutlet var tableView: UITableView!
    
    override func viewDidLoad() {
         loadRole()
        let tableAsArray = TableData["Activities"].arrayValue
        print("table array count(1)= " + (tableAsArray.count.description))
        print(TableData)

        super.viewDidLoad()
       
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
     func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        //NUMBER OF SECTIONS
        return 1
        
    }
     func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //  return data.count                 NUMBER OF ROWS
        
        
        
        //MAKE THIS ALSO THE LENGTH OF THE ARRAY, ONCE I FIGURE THAT OUT ***
        
        
        
        return 3
    }
    
    
    
    
    
    
    
    
     func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        //POPULATING CELLS
        
        
        
        let cell=UITableViewCell()
        //cell.textLabel?.text = ("Testing " + indexPath.row.description)
        var roleJO = TableData["Activities"][indexPath.row]
        let roleName = roleJO["eventName"].stringValue
        
        cell.textLabel?.text = roleName
        
        
        cell.accessoryType = .DisclosureIndicator
        return cell;
        
        
    }
    
    
     func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        //HEADER
        return "Select Group to Check In"
    }
    
    
    //"on click"
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let row = indexPath.row
        print("Row: \(row) clicked on Role")
        let storyboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        
        if(row==2){
            let destination = storyboard.instantiateViewControllerWithIdentifier("IluminatiViewController")
            navigationController?.showViewController(destination, sender: true)
        }
        else{
            let destination = storyboard.instantiateViewControllerWithIdentifier("GroupViewController")
            navigationController?.showViewController(destination, sender: true)
        }
       
        
    }
    
    
    
    
    
    
    var TableData: JSON = []

    func loadRole() {
        //I removed parameters from the request (see original "loadActivities" in activities file)
        SwiftSpinner.show("Loading Roles");
        
        Alamofire.request(.GET,"http://saa.ma1geek.org/getActivities.php?date=2016-03-08").responseJSON{response in
            SwiftSpinner.hide();
            if let data = response.2.value {
                let json = JSON(data)
                self.TableData = json
                dispatch_async(dispatch_get_main_queue(), {
                   self.tableView.reloadData()
                    print("Loaded roles")
                    return
                })
                // see https://github.com/SwiftyJSON/SwiftyJSON
            }
            else {
                let alert = UIAlertView();
                alert.title = "Try again"
                alert.message = "Please check your network connection to load the latest activities."
                alert.addButtonWithTitle("OK")
                alert.show()
            }
        }
        
    }//load

    
    
    
    
    
    
    
    
}
