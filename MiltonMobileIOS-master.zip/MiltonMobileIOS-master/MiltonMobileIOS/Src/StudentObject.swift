//
//  StudentObject.swift
//  MiltonMobileIOS
//
//  Created by Henry Westerman on 7/1/16.
//  Copyright © 2016 Milton Academy. All rights reserved.
//

import Foundation


class Student {
    var FirstName: String
    var LastName: String
    var StudentID: String
    var FullName: String
    
    init(FirstName:String, LastName:String, StudentID:String, test:Int) {
        self.FirstName=FirstName
        self.LastName=LastName
        self.StudentID=StudentID
        self.FullName=FirstName+" "+LastName
    }
   
}